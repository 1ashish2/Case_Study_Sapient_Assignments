export const cartData={
    "response": "Success",
    "responseMessage": "Product added to cart successfully"
  }